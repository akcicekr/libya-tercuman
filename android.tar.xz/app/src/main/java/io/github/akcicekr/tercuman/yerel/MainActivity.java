package io.github.akcicekr.tercuman.yerel;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Libya Tercüman – kulaklık ayrımlı yerel Android sürümü.
 * Web uygulamasını açar; sesli okuma ve ses tanımayı telefonun kendi sistemiyle yapar.
 * Kulaklık takılıyken: "ear" sesi kulaklığa, "spk" sesi telefon hoparlörüne yönlendirilir.
 */
public class MainActivity extends Activity {
    private static final String HOME = "https://akcicekr.github.io/libya-tercuman/";
    private static final String HOST = "akcicekr.github.io";
    private static final int REQ_MIC = 1, REQ_CAM = 2, REQ_FILE = 3;

    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private AudioManager am;
    private MediaPlayer player;
    private boolean commActive = false;
    private SpeechRecognizer rec;
    private PermissionRequest pendingPerm;
    private ValueCallback<Uri[]> fileCb;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private int seq = 0;
    private final Map<String, String[]> jobs = new HashMap<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);

        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUserAgentString(s.getUserAgentString() + " LTNative/1");
        web.addJavascriptInterface(new Bridge(), "LTNative");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return handleUrl(r.getUrl().toString());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest r) {
                ui.post(() -> {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        r.grant(r.getResources());
                    } else {
                        pendingPerm = r;
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAM);
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    Intent i = p.createIntent();
                    i.setAction(Intent.ACTION_GET_CONTENT);
                    i.setType("image/*");
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(Intent.createChooser(i, "Resim seç"), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });

        tts = new TextToSpeech(this, st -> ttsReady = (st == TextToSpeech.SUCCESS));
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { }
            @Override public void onDone(String id) { ui.post(() -> play(id)); }
            @Override public void onError(String id) { ui.post(() -> jobs.remove(id)); }
        });

        List<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.BLUETOOTH_CONNECT);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_MIC);

        web.loadUrl(HOME);
    }

    private boolean handleUrl(String url) {
        try {
            if (url.startsWith("intent:")) {
                Intent i = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                try {
                    startActivity(i);
                } catch (ActivityNotFoundException e) {
                    String fb = i.getStringExtra("browser_fallback_url");
                    if (fb != null) startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(fb)));
                }
                return true;
            }
            Uri u = Uri.parse(url);
            if (HOST.equals(u.getHost())) return false;
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (Exception ignored) { }
        return true;
    }

    // ---------------- Ses çıkışı ----------------

    private static boolean isEar(int t) {
        return t == AudioDeviceInfo.TYPE_WIRED_HEADSET || t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES
                || t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
                || t == AudioDeviceInfo.TYPE_USB_HEADSET || t == 26 /* TYPE_BLE_HEADSET */;
    }

    private boolean hasHeadset() {
        for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS))
            if (isEar(d.getType())) return true;
        return false;
    }

    private AudioDeviceInfo findOutput(String route) {
        AudioDeviceInfo best = null;
        for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
            int t = d.getType();
            if ("spk".equals(route) && t == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER) return d;
            if ("rcv".equals(route) && t == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE) return d;
            if ("ear".equals(route) && isEar(t)) {
                if (t != AudioDeviceInfo.TYPE_BLUETOOTH_SCO) return d; // medya için A2DP/kablolu tercih
                best = d;
            }
        }
        return best;
    }

    private void startComm(String route) {
        try {
            am.setMode(AudioManager.MODE_IN_COMMUNICATION);
            if (Build.VERSION.SDK_INT >= 31) {
                for (AudioDeviceInfo d : am.getAvailableCommunicationDevices()) {
                    int t = d.getType();
                    boolean ok = "spk".equals(route) ? t == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
                            : "rcv".equals(route) ? t == AudioDeviceInfo.TYPE_BUILTIN_EARPIECE
                            : (isEar(t) && t != AudioDeviceInfo.TYPE_BLUETOOTH_A2DP);
                    if (ok) { am.setCommunicationDevice(d); break; }
                }
            } else {
                am.setSpeakerphoneOn("spk".equals(route));
            }
            commActive = true;
        } catch (Exception ignored) { }
    }

    private void endComm() {
        if (!commActive) return;
        commActive = false;
        try {
            if (Build.VERSION.SDK_INT >= 31) am.clearCommunicationDevice();
            else am.setSpeakerphoneOn(false);
            am.setMode(AudioManager.MODE_NORMAL);
        } catch (Exception ignored) { }
    }

    private void stopAudio() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) { }
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
        try { tts.stop(); } catch (Exception ignored) { }
        endComm();
    }

    private void speak(String text, String lang, String route, String method, float rate) {
        stopAudio();
        if (!ttsReady || text == null || text.trim().isEmpty()) return;
        Locale loc = Locale.forLanguageTag(lang);
        int r = tts.setLanguage(loc);
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)
            tts.setLanguage(new Locale(loc.getLanguage()));
        tts.setSpeechRate(rate > 0 ? rate : 0.9f);
        String id = "u" + (++seq);
        jobs.put(id, new String[]{route, method});
        File f = new File(getCacheDir(), id + ".wav");
        tts.synthesizeToFile(text, new Bundle(), f, id);
    }

    private void play(String id) {
        String[] job = jobs.remove(id);
        final File f = new File(getCacheDir(), id + ".wav");
        if (job == null || !id.equals("u" + seq)) { f.delete(); return; } // eskimiş istek
        String route = job[0], method = job[1];
        final boolean headset = hasHeadset();
        boolean split = headset && !"auto".equals(route);
        final boolean comm = split && ("call".equals(method) || "rcv".equals(route));
        final boolean alarm = split && !comm && "alarm".equals(method) && !"ear".equals(route);
        try {
            final MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(comm ? AudioAttributes.USAGE_VOICE_COMMUNICATION : alarm ? AudioAttributes.USAGE_ALARM : AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
            mp.setDataSource(f.getPath());
            if (comm) startComm(route);
            mp.prepare();
            if (split && !comm && !alarm && Build.VERSION.SDK_INT >= 28) {
                AudioDeviceInfo d = findOutput(route);
                if (d != null) mp.setPreferredDevice(d);
            }
            mp.setOnCompletionListener(m -> {
                try { m.release(); } catch (Exception ignored) { }
                if (player == m) player = null;
                if (comm) endComm();
                f.delete();
            });
            player = mp;
            if (comm) ui.postDelayed(() -> { if (player == mp) mp.start(); }, 350);
            else mp.start();
            final String m0 = comm ? "arama" : alarm ? "alarm" : "normal";
            ui.postDelayed(() -> report("hedef=" + route + ", yöntem=" + m0 + ", kulaklık=" + (headset ? "var" : "yok")
                    + ", çalan=" + routedName(mp)), 900);
        } catch (Exception e) {
            endComm();
            f.delete();
        }
    }

    private static String typeName(int t) {
        switch (t) {
            case AudioDeviceInfo.TYPE_BUILTIN_SPEAKER: return "hoparlör";
            case AudioDeviceInfo.TYPE_BUILTIN_EARPIECE: return "ahize";
            case AudioDeviceInfo.TYPE_WIRED_HEADSET: return "kablolu kulaklık(mik)";
            case AudioDeviceInfo.TYPE_WIRED_HEADPHONES: return "kablolu kulaklık";
            case AudioDeviceInfo.TYPE_BLUETOOTH_A2DP: return "bluetooth(müzik)";
            case AudioDeviceInfo.TYPE_BLUETOOTH_SCO: return "bluetooth(arama)";
            case AudioDeviceInfo.TYPE_USB_HEADSET: return "USB kulaklık";
            case 26: return "bluetooth LE";
            default: return "tip" + t;
        }
    }

    private String routedName(MediaPlayer mp) {
        try {
            if (Build.VERSION.SDK_INT >= 28 && player == mp) {
                AudioDeviceInfo d = mp.getRoutedDevice();
                if (d != null) return typeName(d.getType());
            }
        } catch (Exception ignored) { }
        return "?";
    }

    private String devices() {
        StringBuilder b = new StringBuilder("Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + "), " + Build.MANUFACTURER + " " + Build.MODEL + "; çıkışlar: ");
        for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) b.append(typeName(d.getType())).append(", ");
        return b.toString();
    }

    private void report(String info) {
        final String code = "window.__ltAudio&&window.__ltAudio(" + JSONObject.quote(info) + ")";
        web.evaluateJavascript(code, null);
    }

    // ---------------- Ses tanıma ----------------

    private void js(String type, String text) {
        final String code = "window.__ltRec&&window.__ltRec('" + type + "'," + JSONObject.quote(text == null ? "" : text) + ")";
        ui.post(() -> web.evaluateJavascript(code, null));
    }

    private static String first(Bundle b) {
        ArrayList<String> l = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return (l != null && !l.isEmpty()) ? l.get(0) : null;
    }

    private static String errName(int e) {
        switch (e) {
            case SpeechRecognizer.ERROR_NO_MATCH:
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "no-speech";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "not-allowed";
            case SpeechRecognizer.ERROR_NETWORK:
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "network";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "busy";
            default: return "e" + e;
        }
    }

    private void listen(String lang) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { js("end", "nosr"); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            js("end", "not-allowed");
            return;
        }
        stopAudio();
        if (rec != null) { try { rec.destroy(); } catch (Exception ignored) { } }
        rec = SpeechRecognizer.createSpeechRecognizer(this);
        rec.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle p) { }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float v) { }
            @Override public void onBufferReceived(byte[] b) { }
            @Override public void onEndOfSpeech() { }
            @Override public void onEvent(int t, Bundle p) { }
            @Override public void onPartialResults(Bundle b) { String t = first(b); if (t != null && !t.isEmpty()) js("partial", t); }
            @Override public void onResults(Bundle b) { String t = first(b); if (t != null && !t.isEmpty()) js("final", t); js("end", ""); }
            @Override public void onError(int e) { js("end", errName(e)); }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        try { rec.startListening(i); } catch (Exception e) { js("end", "start"); }
    }

    // ---------------- JavaScript köprüsü ----------------

    private class Bridge {
        @JavascriptInterface public void speak(String text, String lang, String route, String method, float rate) {
            ui.post(() -> MainActivity.this.speak(text, lang, route, method, rate));
        }
        @JavascriptInterface public void stop() { ui.post(MainActivity.this::stopAudio); }
        @JavascriptInterface public void listen(String lang) { ui.post(() -> MainActivity.this.listen(lang)); }
        @JavascriptInterface public void stopListen() { ui.post(() -> { if (rec != null) rec.stopListening(); }); }
        @JavascriptInterface public boolean hasHeadset() { return MainActivity.this.hasHeadset(); }
        @JavascriptInterface public String version() { return "2"; }
        @JavascriptInterface public String devices() { return MainActivity.this.devices(); }
    }

    // ---------------- Yaşam döngüsü ----------------

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCb != null) {
            Uri[] r = null;
            if (res == RESULT_OK && data != null && data.getData() != null) r = new Uri[]{data.getData()};
            fileCb.onReceiveValue(r);
            fileCb = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_CAM && pendingPerm != null) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) pendingPerm.grant(pendingPerm.getResources());
            else pendingPerm.deny();
            pendingPerm = null;
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.__ltBack&&window.__ltBack())?1:0", v -> {
            if ("1".equals(v)) return;
            if (web.canGoBack()) web.goBack();
            else MainActivity.super.onBackPressed();
        });
    }

    @Override
    protected void onDestroy() {
        stopAudio();
        if (rec != null) { try { rec.destroy(); } catch (Exception ignored) { } }
        if (tts != null) tts.shutdown();
        web.destroy();
        super.onDestroy();
    }
}
