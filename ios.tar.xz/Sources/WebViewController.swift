import UIKit
import WebKit
import AVFoundation
import Speech

/// Libya Tercüman – iPhone sürümü.
/// Web uygulamasını açar; Android sürümündeki "LTNative" köprüsünün aynısını sağlar:
/// sesli okuma (kulaklık/hoparlör ayrımıyla), konuşma tanıma ve ekranı açık tutma.
final class WebViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate,
                               WKUIDelegate, AVSpeechSynthesizerDelegate {

    private static let home = URL(string: "https://akcicekr.github.io/libya-tercuman/")!
    private static let host = "akcicekr.github.io"

    private var web: WKWebView!
    private let synth = AVSpeechSynthesizer()
    private let session = AVAudioSession.sharedInstance()
    private var overrideOn = false
    private var headset = false

    // Konuşma tanıma
    private let engine = AVAudioEngine()
    private var recRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recTask: SFSpeechRecognitionTask?
    private var silenceTimer: Timer?
    private var lastText = ""
    private var recFinished = true

    // Web sayfası açılmadan önce eklenen köprü (Android'deki arayüzle aynı adlar)
    private static let shim = """
    (function(){
      var post=function(m){try{window.webkit.messageHandlers.lt.postMessage(m);}catch(e){}};
      window.__ltHs=false;window.__ltDev="";
      window.LTNative={
        platform:"ios",
        speak:function(t,l,r,m,rate){post({op:"speak",text:String(t||""),lang:String(l||"tr-TR"),route:String(r||"auto"),rate:Number(rate)||0.9});},
        stop:function(){post({op:"stop"});},
        listen:function(l){post({op:"listen",lang:String(l||"tr-TR")});},
        stopListen:function(){post({op:"stopListen"});},
        hasHeadset:function(){return !!window.__ltHs;},
        devices:function(){return window.__ltDev||"";},
        keepScreen:function(on){post({op:"keep",on:!!on});},
        version:function(){return "ios1";}
      };
    })();
    """

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.96, green: 0.95, blue: 0.92, alpha: 1)

        let cfg = WKWebViewConfiguration()
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []
        cfg.applicationNameForUserAgent = "LTNativeIOS/1"
        let uc = WKUserContentController()
        uc.add(self, name: "lt")
        uc.addUserScript(WKUserScript(source: Self.shim, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        cfg.userContentController = uc

        web = WKWebView(frame: .zero, configuration: cfg)
        web.navigationDelegate = self
        web.uiDelegate = self
        web.allowsBackForwardNavigationGestures = true
        web.isOpaque = false
        web.backgroundColor = view.backgroundColor
        web.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(web)
        NSLayoutConstraint.activate([
            web.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            web.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            web.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            web.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        synth.delegate = self
        setupAudio()
        NotificationCenter.default.addObserver(self, selector: #selector(routeChanged),
                                               name: AVAudioSession.routeChangeNotification, object: nil)
        SFSpeechRecognizer.requestAuthorization { _ in }
        session.requestRecordPermission { _ in }

        web.load(URLRequest(url: Self.home))
    }

    // MARK: - Ses oturumu ve çıkış yönlendirme

    private func setupAudio() {
        do {
            // playAndRecord: hem mikrofon hem çalma; defaultToSpeaker: kulaklık yokken ahize yerine hoparlör
            try session.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker, .allowBluetoothA2DP])
            try session.setActive(true)
        } catch { }
        headset = computeHeadset()
        pushRoute()
    }

    private func computeHeadset() -> Bool {
        let ear: [AVAudioSession.Port] = [.headphones, .bluetoothA2DP, .bluetoothHFP, .bluetoothLE, .usbAudio]
        return session.currentRoute.outputs.contains { ear.contains($0.portType) }
    }

    private func portName(_ p: AVAudioSession.Port) -> String {
        switch p {
        case .builtInSpeaker: return "hoparlör"
        case .builtInReceiver: return "ahize"
        case .headphones: return "kablolu kulaklık"
        case .bluetoothA2DP: return "bluetooth(müzik)"
        case .bluetoothHFP: return "bluetooth(arama)"
        case .bluetoothLE: return "bluetooth LE"
        case .usbAudio: return "USB ses"
        default: return p.rawValue
        }
    }

    @objc private func routeChanged() {
        DispatchQueue.main.async {
            if !self.overrideOn { self.headset = self.computeHeadset() }
            self.pushRoute()
        }
    }

    private func pushRoute() {
        guard web != nil else { return }
        let outs = session.currentRoute.outputs.map { portName($0.portType) }.joined(separator: ", ")
        let info = "iOS \(UIDevice.current.systemVersion), \(UIDevice.current.model); çıkış: \(outs)"
        web.evaluateJavaScript("window.__ltHs=\(headset ? "true" : "false");window.__ltDev=\(jsString(info));", completionHandler: nil)
    }

    private func setOutput(toSpeaker: Bool) {
        do {
            try session.overrideOutputAudioPort(toSpeaker ? .speaker : .none)
            overrideOn = toSpeaker
        } catch { overrideOn = false }
    }

    // MARK: - Sesli okuma

    private func speak(_ text: String, lang: String, route: String, rate: Double) {
        stopSpeaking()
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        try? session.setActive(true)
        // Kulaklık takılıyken: Türkçe ("ear") kulaklığa, Arapça/İngilizce ("spk" / "rcv") telefonun hoparlörüne
        setOutput(toSpeaker: headset && (route == "spk" || route == "rcv"))
        let u = AVSpeechUtterance(string: text)
        u.voice = voice(for: lang)
        u.rate = Float(max(0.3, min(1.2, rate))) * AVSpeechUtteranceDefaultSpeechRate
        synth.speak(u)
    }

    private func voice(for tag: String) -> AVSpeechSynthesisVoice? {
        let lang = tag.lowercased()
        let prefs: [String]
        if lang.hasPrefix("ar") { prefs = ["ar-SA", "ar-001", "ar"] }
        else if lang.hasPrefix("en") { prefs = ["en-US", "en-GB", "en"] }
        else { prefs = ["tr-TR", "tr"] }
        for p in prefs { if let v = AVSpeechSynthesisVoice(language: p) { return v } }
        return nil
    }

    private func stopSpeaking() {
        if synth.isSpeaking { synth.stopSpeaking(at: .immediate) }
        if overrideOn { setOutput(toSpeaker: false) }
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        speechEnded()
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        speechEnded()
    }

    private func speechEnded() {
        DispatchQueue.main.async {
            if self.overrideOn { self.setOutput(toSpeaker: false) }
            self.web.evaluateJavaScript("window.__ltSpeakDone&&window.__ltSpeakDone()", completionHandler: nil)
        }
    }

    // MARK: - Konuşma tanıma

    private func recJS(_ type: String, _ text: String) {
        web.evaluateJavaScript("window.__ltRec&&window.__ltRec('\(type)',\(jsString(text)))", completionHandler: nil)
    }

    private func listen(_ lang: String) {
        finishRecognition(report: false)
        guard let recognizer = SFSpeechRecognizer(locale: Locale(identifier: lang)), recognizer.isAvailable else {
            recJS("end", "nosr"); return
        }
        guard SFSpeechRecognizer.authorizationStatus() == .authorized else {
            SFSpeechRecognizer.requestAuthorization { _ in }
            recJS("end", "not-allowed"); return
        }
        stopSpeaking()
        try? session.setActive(true)

        let req = SFSpeechAudioBufferRecognitionRequest()
        req.shouldReportPartialResults = true
        recRequest = req
        lastText = ""
        recFinished = false

        let input = engine.inputNode
        let format = input.outputFormat(forBus: 0)
        input.removeTap(onBus: 0)
        input.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, _ in
            req.append(buffer)
        }
        engine.prepare()
        do { try engine.start() } catch {
            recFinished = true
            recJS("end", "start"); return
        }

        recTask = recognizer.recognitionTask(with: req) { [weak self] result, error in
            DispatchQueue.main.async {
                guard let self = self, !self.recFinished else { return }
                if let r = result {
                    let t = r.bestTranscription.formattedString
                    if !t.isEmpty {
                        self.lastText = t
                        self.recJS("partial", t)
                        self.armSilence(1.3)   // susunca 1,3 sn sonra bitir
                    }
                    if r.isFinal { self.finishRecognition(report: true) }
                } else if error != nil {
                    self.finishRecognition(report: true)
                }
            }
        }
        armSilence(7.0) // hiç konuşulmazsa
    }

    private func armSilence(_ seconds: TimeInterval) {
        silenceTimer?.invalidate()
        silenceTimer = Timer.scheduledTimer(withTimeInterval: seconds, repeats: false) { [weak self] _ in
            self?.finishRecognition(report: true)
        }
    }

    private func finishRecognition(report: Bool) {
        if recFinished { return }
        recFinished = true
        silenceTimer?.invalidate()
        silenceTimer = nil
        if engine.isRunning { engine.stop() }
        engine.inputNode.removeTap(onBus: 0)
        recRequest?.endAudio()
        recTask?.cancel()
        recRequest = nil
        recTask = nil
        guard report else { return }
        if lastText.isEmpty {
            recJS("end", "no-speech")
        } else {
            recJS("final", lastText)
            recJS("end", "")
        }
    }

    // MARK: - JavaScript köprüsü

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let d = message.body as? [String: Any], let op = d["op"] as? String else { return }
        switch op {
        case "speak":
            speak(d["text"] as? String ?? "", lang: d["lang"] as? String ?? "tr-TR",
                  route: d["route"] as? String ?? "auto", rate: (d["rate"] as? Double) ?? 0.9)
        case "stop":
            stopSpeaking()
        case "listen":
            listen(d["lang"] as? String ?? "tr-TR")
        case "stopListen":
            finishRecognition(report: true)
        case "keep":
            UIApplication.shared.isIdleTimerDisabled = (d["on"] as? Bool) ?? false
        default:
            break
        }
    }

    // MARK: - Gezinme, izinler, uyarılar

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        pushRoute()
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url, let scheme = url.scheme?.lowercased() else {
            decisionHandler(.allow); return
        }
        if scheme == "intent" {
            // Android'e özel bağlantı: içindeki web adresine git
            if let fb = intentFallback(url.absoluteString) { UIApplication.shared.open(fb) }
            decisionHandler(.cancel); return
        }
        if ["about", "blob", "data"].contains(scheme) || url.host == Self.host {
            decisionHandler(.allow); return
        }
        if (scheme == "http" || scheme == "https"), navigationAction.targetFrame?.isMainFrame ?? true {
            UIApplication.shared.open(url)
            decisionHandler(.cancel); return
        }
        if !["http", "https"].contains(scheme) {
            UIApplication.shared.open(url)
            decisionHandler(.cancel); return
        }
        decisionHandler(.allow)
    }

    private func intentFallback(_ s: String) -> URL? {
        guard let r = s.range(of: "S.browser_fallback_url=") else { return nil }
        var v = String(s[r.upperBound...])
        if let end = v.firstIndex(of: ";") { v = String(v[..<end]) }
        return URL(string: v.removingPercentEncoding ?? v)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url { UIApplication.shared.open(url) }
        return nil
    }

    func webView(_ webView: WKWebView, requestMediaCapturePermissionFor origin: WKSecurityOrigin,
                 initiatedByFrame frame: WKFrameInfo, type: WKMediaCaptureType,
                 decisionHandler: @escaping (WKPermissionDecision) -> Void) {
        decisionHandler(origin.host == Self.host ? .grant : .prompt)
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Tamam", style: .default) { _ in completionHandler() })
        present(a, animated: true)
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Vazgeç", style: .cancel) { _ in completionHandler(false) })
        a.addAction(UIAlertAction(title: "Tamam", style: .default) { _ in completionHandler(true) })
        present(a, animated: true)
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        webView.reload()
    }

    // MARK: - Yardımcı

    private func jsString(_ s: String) -> String {
        if let d = try? JSONEncoder().encode(s), let out = String(data: d, encoding: .utf8) { return out }
        return "\"\""
    }
}
